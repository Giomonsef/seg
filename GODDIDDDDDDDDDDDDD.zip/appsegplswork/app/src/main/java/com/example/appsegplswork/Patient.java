package com.example.appsegplswork;

public class Patient {
    private String patientName;
    private String patientLastName;
    private String patientEmail;
    private String patientPassword;
    private String patientPhone;
    private String patientAdd;
    private String healthNum;

    // Constructor
    public Patient(String patientName, String patientLastName, String patientEmail,
                   String patientPassword, String patientPhone, String patientAdd,
                   String healthNum) {
        this.patientName = patientName;
        this.patientLastName = patientLastName;
        this.patientEmail = patientEmail;
        this.patientPassword = patientPassword;
        this.patientPhone = patientPhone;
        this.patientAdd = patientAdd;
        this.healthNum = healthNum;
    }

    // Getters and Setters
    public String getPatientName() {
        return patientName;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }

    public String getPatientLastName() {
        return patientLastName;
    }

    public void setPatientLastName(String patientLastName) {
        this.patientLastName = patientLastName;
    }

    public String getPatientEmail() {
        return patientEmail;
    }

    public void setPatientEmail(String patientEmail) {
        this.patientEmail = patientEmail;
    }

    public String getPatientPassword() {
        return patientPassword;
    }

    public void setPatientPassword(String patientPassword) {
        this.patientPassword = patientPassword;
    }

    public String getPatientPhone() {
        return patientPhone;
    }

    public void setPatientPhone(String patientPhone) {
        this.patientPhone = patientPhone;
    }

    public String getPatientAdd() {
        return patientAdd;
    }

    public void setPatientAdd(String patientAdd) {
        this.patientAdd = patientAdd;
    }

    public String getHealthNum() {
        return healthNum;
    }

    public void setHealthNum(String healthNum) {
        this.healthNum = healthNum;
    }
}
