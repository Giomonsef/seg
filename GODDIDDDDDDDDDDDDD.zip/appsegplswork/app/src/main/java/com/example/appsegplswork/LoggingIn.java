package com.example.appsegplswork;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class LoggingIn extends AppCompatActivity {

    private Button backToMain;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.logging_in);

        backToMain = (Button) findViewById(R.id.BackToMainMenu);

        backToMain.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){backToTheMainMenu();
            }
        });

    }

    public void backToTheMainMenu(){
        Intent intent= new Intent(this, MainMenu.class);
        startActivity(intent);
    }
}