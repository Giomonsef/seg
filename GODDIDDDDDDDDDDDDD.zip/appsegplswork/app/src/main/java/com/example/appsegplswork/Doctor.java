package com.example.appsegplswork;

import android.widget.EditText;

import java.util.ArrayList;

public class Doctor{

    private String doctorName;
    private String doctorLastName;
    private String doctorEmail;
    private String doctorPassword;
    private Integer doctorPhoneNumber;
    private String doctorAddress;
    private Integer employeeNumber;
    private String specialties;

    public Doctor(String doctorName, String doctorLastName, String doctorEmail, String doctorPassword, Integer doctorPhoneNumber, String doctorAddress, Integer employeeNumber, String specialties) {

        this.doctorName = doctorName;
        this.doctorLastName = doctorLastName;
        this.doctorEmail = doctorEmail;
        this.doctorPassword = doctorPassword;
        this.doctorPhoneNumber = doctorPhoneNumber;
        this.doctorAddress = doctorAddress;
        this.employeeNumber = employeeNumber;
        this.specialties = specialties;
    }
    public String getDoctorName() {
        return doctorName;
    }
    public String getDoctorLastName() {
        return doctorLastName;
    }

    public String getDoctorEmail() {
        return doctorEmail;
    }

    public String getDoctorPassword() {
        return doctorPassword;
    }

    public Integer getDoctorPhoneNumber() {
        return doctorPhoneNumber;
    }

    public String getDoctorAddress() {
        return doctorAddress;
    }

    public Integer getEmployeeNumber() {
        return employeeNumber;
    }

    public String getSpecialties() {
        return specialties;
    }

    public void setDoctorLastName(String doctorLastName) {
        this.doctorLastName = doctorLastName;
    }

    public void setDoctorEmail(String doctorEmail) {
        this.doctorEmail = doctorEmail;
    }

    public void setDoctorPassword(String doctorPassword) {
        this.doctorPassword = doctorPassword;
    }

    public void setDoctorPhoneNumber(Integer doctorPhoneNumber) {
        this.doctorPhoneNumber = doctorPhoneNumber;
    }

    public void setDoctorAddress(String doctorAddress) {
        this.doctorAddress = doctorAddress;
    }

    public void setEmployeeNumber(Integer employeeNumber) {
        this.employeeNumber = employeeNumber;
    }

    public void setSpecialties(String specialties) {
        this.specialties = specialties;
    }

    public void setDoctorName(String doctorName) {this.doctorName = doctorName;}
}
