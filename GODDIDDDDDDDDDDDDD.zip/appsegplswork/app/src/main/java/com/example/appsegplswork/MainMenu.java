package com.example.appsegplswork;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainMenu extends AppCompatActivity {

    private Button registerButton;
    private Button loginButton;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        registerButton = (Button) findViewById(R.id.administrator);
        loginButton = (Button) findViewById(R.id.patient);


        registerButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){openScreen2();
            }
        });

        loginButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                openLogin();
            }
        });

    }
    public void openScreen2(){
        Intent intent= new Intent(this, RegisterScreen.class);
        startActivity(intent);
    }

    public void openLogin(){
        Intent intent= new Intent(this, LoggingIn.class);
        startActivity(intent);
    }
}