package com.example.appsegplswork;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class RegisterScreen extends AppCompatActivity {

    private Button doctorButton;
    private Button patientButton;
    private Button backButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        doctorButton = (Button) findViewById(R.id.doctor);
        patientButton = (Button) findViewById(R.id.patient);
        backButton = (Button) findViewById(R.id.ReturnToMainMenu);

        doctorButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){openDoctorRegistration();
            }
        });

        patientButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){openPatientRegistration();
            }
        });

        backButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){backToMainMenu();
            }
        });
    }

    public void openPatientRegistration() {
        Intent intent= new Intent(this, PatientRegistration.class);
        startActivity(intent);
    }

    public void openDoctorRegistration() {
        Intent intent= new Intent(this, DoctorRegistration.class);
        startActivity(intent);
    }

    public void backToMainMenu() {
        Intent intent= new Intent(this, MainMenu.class);
        startActivity(intent);
    }
}