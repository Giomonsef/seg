package com.example.appsegplswork;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class PatientRegistration extends AppCompatActivity {

    FirebaseDatabase database;
    DatabaseReference databaseReference;

    private Button submitToLogin;
    private Button BackToMainMenu;
    private EditText patientName;
    private EditText patientLastName;
    private EditText patientEmail;
    private EditText patientPassword;
    private EditText patientPhoneNumber;
    private EditText patientAddress;
    private EditText patientHealthCardNumber;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.patient_registration);

        database = FirebaseDatabase.getInstance();
        databaseReference = database.getReference("Users");

        patientName = findViewById(R.id.patientName);
        patientLastName = findViewById(R.id.patientLastName);
        patientEmail = findViewById(R.id.patientEmail);
        patientPassword = findViewById(R.id.patientPassword);
        patientPhoneNumber = findViewById(R.id.patientPhoneNumber);
        patientAddress = findViewById(R.id.patientAddress);
        patientHealthCardNumber = findViewById(R.id.patientHealthCardNumber);

        submitToLogin = (Button) findViewById(R.id.submitPatientLogin);
        BackToMainMenu = (Button) findViewById(R.id.BackToRegister);

        submitToLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = patientName.getText().toString();
                String lastName = patientLastName.getText().toString();
                String email = patientEmail.getText().toString();
                String password = patientPassword.getText().toString();
                String phone = patientPhoneNumber.getText().toString();
                String patientAdd = patientAddress.getText().toString();
                String healthCardNumber = patientHealthCardNumber.getText().toString();

                boolean checkInfo = validateInformation(name, lastName, email, password, phone, patientAdd, healthCardNumber);

                if (checkInfo) {
                    Toast.makeText(getApplicationContext(), "Data is Valid", Toast.LENGTH_SHORT).show();
                    Patient patient = new Patient(name, lastName, email, password, phone, patientAdd, healthCardNumber);
                    databaseReference.child(healthCardNumber).setValue(healthCardNumber);
                    openLoginPage(); // Only open the next screen if data is valid
                }

                else {
                    Toast.makeText(getApplicationContext(), "Check if the information is correct", Toast.LENGTH_SHORT).show();
                }
            }
        });

        BackToMainMenu.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){openMainMenu();
            }
        });
    }

    private Boolean validateInformation(String name, String lastName, String email, String password, String phoneNumber, String patientAdd, String healthCard){
        if(name.length() == 0){
            patientName.requestFocus();
            patientName.setError("Name cannot be empty");
            return false;
        }

        else if(!name.matches("[a-zA-Z]+")){
            patientName.requestFocus();
            patientName.setError("Name has to only have characters");
            return false;
        }

        if(lastName.length() == 0){
            patientLastName.requestFocus();
            patientLastName.setError("Name cannot be empty");
            return false;
        }

        else if(!lastName.matches("[a-zA-Z]+")){
            patientLastName.requestFocus();
            patientLastName.setError("Name has to only have characters");
            return false;
        }

        else if(email.length()==0){
            patientEmail.requestFocus();
            patientEmail.setError("Email cannot be empty");
            return false;
        }

        else if(!email.matches("[a-zA-Z._-]+@[1-z]+\\.+[a-z=]+")){
            patientEmail.requestFocus();
            patientEmail.setError("Name has to only have characters");
            return false;
        }

        else if(phoneNumber.length()==0){
            patientPhoneNumber.requestFocus();
            patientPhoneNumber.setError("Phone cannot be empty");
            return false;
        }

        else if (password.length() == 0){
            patientPassword.requestFocus();
            patientPassword.setError("Password cannot be empty");
            return false;
        }

        else if (patientAdd.length() == 0){
            patientAddress.requestFocus();
            patientAddress.setError("Address cannot be empty");
            return false;
        }

        else if (healthCard.length() == 0){
            patientHealthCardNumber.requestFocus();
            patientHealthCardNumber.setError("Health card number cannot be empty");
            return false;
        }
        return true;
    }

    public void openLoginPage() {
        Intent intent= new Intent(this, LoggingIn.class);
        startActivity(intent);

    }

    public void openMainMenu() {
        Intent intent= new Intent(this, RegisterScreen.class);
        startActivity(intent);
    }


}