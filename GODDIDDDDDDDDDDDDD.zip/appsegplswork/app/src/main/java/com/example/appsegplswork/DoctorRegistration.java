package com.example.appsegplswork;

import static android.content.ContentValues.TAG;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.appsegplswork.R.id;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class DoctorRegistration extends AppCompatActivity {

    FirebaseDatabase database;
    DatabaseReference databaseReference;

    private Button submitDoctorLogin;
    private Button backToMenu;
    private EditText doctorName;
    private EditText doctorLastName;
    private EditText doctorEmail;
    private EditText doctorPassword;
    private EditText doctorPhoneNumber;
    private EditText doctorAddress;
    private EditText employeeNumber;
    private EditText specialties;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.doctor_registration);

        database = FirebaseDatabase.getInstance();
        databaseReference = database.getReference("Users");

        doctorName = findViewById(R.id.doctorName);
        doctorLastName = findViewById(R.id.doctorLastName);
        doctorEmail = findViewById(R.id.doctorEmail);
        doctorPassword = findViewById(R.id.doctorPassword);
        doctorPhoneNumber = findViewById(R.id.doctorPhoneNumber);
        doctorAddress = findViewById(R.id.doctorAddress);
        employeeNumber = findViewById(R.id.employeeNumber);
        specialties = findViewById(R.id.specialties);

        submitDoctorLogin = (Button) findViewById(R.id.submitDoctor);
        backToMenu = (Button) findViewById(R.id.DoctorRegistrationToMenu);

        submitDoctorLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = doctorName.getText().toString();
                String lastName = doctorLastName.getText().toString();
                String email = doctorEmail.getText().toString();
                String password = doctorPassword.getText().toString();
                String phone = doctorPhoneNumber.getText().toString();
                String doctorAdd = doctorAddress.getText().toString();
                String employeeNum = employeeNumber.getText().toString();
                String specialtiesDoctor = specialties.getText().toString();

                boolean checkInfo = validateInformationDoctor(name, lastName, email, password, phone, doctorAdd, employeeNum);

                if (checkInfo) {
                    Toast.makeText(getApplicationContext(), "Data is Valid", Toast.LENGTH_SHORT).show();
                    Doctor doctor = new Doctor(name, lastName, email, password, Integer.parseInt(phone), doctorAdd, Integer.parseInt(employeeNum), specialtiesDoctor);
                    databaseReference.child(employeeNum).setValue(doctor);


                            openLoginPage(); // Only open the next screen if data is valid
                } else {
                    Toast.makeText(getApplicationContext(), "Check if the information is correct", Toast.LENGTH_SHORT).show();
                }
            }
        });

        backToMenu.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){backToRegistering();

            }
        });
    }

    private Boolean validateInformationDoctor(String name, String lastName, String email, String password, String phoneNumber, String doctorAdd, String employeeNum){
        if(name.length() == 0){
            doctorName.requestFocus();
            doctorName.setError("Name cannot be empty");
            return false;
        }

        else if(!name.matches("[a-zA-Z]+")){
            doctorName.requestFocus();
            doctorName.setError("Name has to only have characters");
            return false;
        }

        if(lastName.length() == 0){
            doctorLastName.requestFocus();
            doctorLastName.setError("Name cannot be empty");
            return false;
        }

        else if(!lastName.matches("[a-zA-Z]+")){
            doctorLastName.requestFocus();
            doctorLastName.setError("Name has to only have characters");
            return false;
        }

        else if(email.length()==0){
            doctorEmail.requestFocus();
            doctorEmail.setError("Email cannot be empty");
            return false;
        }

        else if(!email.matches("[a-zA-Z._-]+@[1-z]+\\.+[a-z=]+")){
            doctorEmail.requestFocus();
            doctorEmail.setError("Name has to only have characters");
            return false;
        }

        else if(phoneNumber.length()==0){
            doctorPhoneNumber.requestFocus();
            doctorPhoneNumber.setError("Phone cannot be empty");
            return false;
        }

        else if (password.length() == 0){
            doctorPassword.requestFocus();
            doctorPassword.setError("Password cannot be empty");
            return false;
        }

        else if (doctorAdd.length() == 0){
            doctorAddress.requestFocus();
            doctorAddress.setError("Address cannot be empty");
            return false;
        }

        else if (employeeNum.length() == 0){
            employeeNumber.requestFocus();
            employeeNumber.setError("Health card number cannot be empty");
            return false;
        }
        return true;
    }

    public void openMainMenu() {
        Intent intent= new Intent(this, RegisterScreen.class);
        startActivity(intent);
    }

    public void openLoginPage() {
        Intent intent= new Intent(this, LoggingIn.class);
        startActivity(intent);
    }

    public void backToRegistering() {
        Intent intent= new Intent(this, RegisterScreen.class);
        startActivity(intent);
    }
}